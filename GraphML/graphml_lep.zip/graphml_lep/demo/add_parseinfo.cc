#include "GraphML.h"

#include <LEDA/string.h>
#include <LEDA/graph.h>

using namespace leda;
using std::cout;
using std::endl;

//add_parseinfo reads a GraphML document from StdIn
//and writes it to StdOut
 

int main(int argC, char* argV[]){
  graph G;
  GraphML GM(G);

  //filename '-' means StdIn
  GM.read("-");

  GM.write(cout, GraphML::schema_spec, true);

  return 0;
}


