
#include "GraphML.h"

#include <LEDA/graphwin.h>
#include <LEDA/file.h>
#include <LEDA/file_panel.h>

using namespace leda;
using std::cout;
using std::endl;

graph g;
GraphWin gw(g, "GraphML Test");




//***********************************************
//*****   I/O operations   **********************
//***********************************************

//method called by save
static void save_doc(string file){
  GraphML gm(g);
  //get data
  node_array<string> labels(g);
  node_array<double> x(g);
  node_array<double> y(g);

  node v;
  forall_nodes(v, g){
    labels[v] = gw.get_user_label(v);
    point p = gw.get_position(v);
    x[v] = p.xcoord();
    y[v] = p.ycoord();
  }
  string def("no default specified");
  double d_double = 0.0;
  gm.new_data("node_label", GraphML::string_data, labels, def, "node label");
  gm.new_data("coord1", GraphML::double_data, x, d_double, "x coordinate");
  gm.new_data("coord2", GraphML::double_data, y, d_double, "y coordinate");


  gm.write(file, GraphML::schema_spec);
}


void save(GraphWin &gw){

  window &W = gw.get_window();

  string fname = gw.get_graphname() + ".xml";
  string dname = gw.get_dirname();
  
  if(gw.get_graph().empty()){
    gw.message("\\bf\\red Empty Graph.");
    gw.wait(5);
    gw.message("");
    return;
  }
  
  file_panel P(W, fname, dname);

  P.set_save_handler(save_doc);
  P.set_save_string("Save as ...");
  P.set_pattern("XML Files(*.xml)", "*.xml");

  W.disable_panel();
  P.open();

  W.enable_panel();
  gw.redraw();

  gw.set_dirname(dname); 

  //set the new graphname
  int len = fname.length();
  len = len - 4;
  fname = fname.head(len);
  gw.set_graphname(fname);
}

//method called by open
static void open_doc(string file){

  GraphML gm(g);

  gm.read(file);
  gw.update_graph();

  gw.set_node_label_type(user_label);

  //coordinates
  node_array<double> x(g);
  node_array<double> y(g);
  bool has_x = false;
  bool has_y = false;
  //labels
  node_array<string> labels(g, "");

  const list<GraphML::gm_handle_type> &handles = gm.node_data_handles();
  list_item it;
  forall_items(it, handles){
    if(gm.data_name(handles[it]) == string("node_label")){
      labels = gm.node_data<string>(handles[it]);
    }
    if(gm.data_name(handles[it]) == string("coord1")){
      has_x = true;
      x = gm.node_data<double>(handles[it]);
    }
    if(gm.data_name(handles[it]) == string("coord2")){
      has_y = true;
      y = gm.node_data<double>(handles[it]);
    }
  }
  //make sure that there are x and y coordinates
  if(!has_x){
    random_source S;
    node v;
    forall_nodes(v, g){
      S >> x[v];
    }
  }
  if(!has_y){
    random_source S;
    node v;
    forall_nodes(v, g){
      S >> y[v];
    }
  }

  gw.set_position(x, y);
  node v;
  forall_nodes(v, g){
    gw.set_user_label(v, labels[v]);
  }

}

void open(GraphWin &gw){
  //remove the old graph
  bool old_flush = gw.set_flush(false);

  node v;
  forall_nodes(v,g){
    gw.del_node(v);
  } 
  
  window &W = gw.get_window();

  string fname = gw.get_graphname() + ".xml";
  string dname = gw.get_dirname();

  file_panel P(W, fname, dname);
  P.set_load_handler(open_doc);
  P.set_load_string("open ...");
  P.set_pattern("XML Files(*.xml)", "*.xml");

  W.disable_panel();
  P.open();

  //gw.zoom_graph();
  gw.place_into_win();

  W.enable_panel();
  gw.redraw();

  gw.set_dirname(dname); 

  //set the new graphname
  int len = fname.length();
  len = len - 4;
  fname = fname.head(len);
  gw.set_graphname(fname);

  gw.set_flush(old_flush);

}


int main(int argC, char* argV[]){

  cout << "test_graphml is a small application of the GraphML class" << endl;
  cout << "it opens a GraphWin "
       << "which can import and export graphs in GraphML format" << endl;

  cout << "stored node-attributes: x- and y-coordinates \n"
       << "                        node user labels" << endl;

  int graphml_menu = gw.add_menu("GraphML");
  gw.add_simple_call(open, "open ...", graphml_menu);
  gw.add_simple_call(save, "save as ...", graphml_menu);

  gw.display();
  while(gw.edit()){};
  

  return 0;

}

