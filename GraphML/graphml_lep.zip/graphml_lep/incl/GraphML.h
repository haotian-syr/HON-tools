#ifndef GRAPHML_HEADER_GUARD
#define GRAPHML_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439001
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include <LEDA/string.h>
#include <LEDA/graph.h>
#include <LEDA/list.h>
#include <LEDA/dictionary.h>


#include "GraphML_reader.h"
#include "GraphML_writer.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

/*{\Manpage{GraphML}{}{GraphML}{gm}
}*/
class GraphML:
public GraphML_reader, 
public GraphML_writer{
  /*{\Mdefinition
|\Mname| extends both
|GraphML_reader| and |GraphML_writer|,
and thus inherits from |GraphML_graph| as well as from
|graphml_attributes<string>|, |graphml_parseinfo<string>| and
|graphml_structure<string>|.

An instance |\Mvar| of |\Mname| is a data structure that holds 
references to a |graph| and associated |node_| and 
|edge_array|s.  It allows to import and export the referenced graph
together with its attributes in GraphML format.  

Any of the following types may be used for attribute data: |bool|, 
|int|, |long|, |float|, |double|, or |string| (i.e.\ |leda_string|). 
Types are identified by instances of 
\begin{quote}
|\Mname::gm_data_type|\\
| = \{bool_data, int_data, long_data, float_data, double_data,
string_data\}|.
\end{quote}

When exporting a graph referred to by |\Mvar| to a GraphML
document, the document type may be specified either using the 
GraphML Schema specification (recommended), or 
the GraphML Document Type Definition (DTD).
The specification method is identified by an instance of 
\begin{quote}
|\Mname::gm_specification_method|\\
| = \{no_spec, schema_spec, dtd_spec\}|.
\end{quote}

Meta-information for light-weight parsers is added upon request.
    }*/


 public:


  /*{\Mcreation 1}*/
  GraphML(graph& G);
  /*{\Mcreate
    creates an instance |\Mvar| of type |\Mname| for graph |G|.
    }*/

  ~GraphML();





 private:

};

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE

#if LEDA_ROOT_INCL_ID == 439001
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif





