#ifndef GRAPHMLWRITER_HEADER_GUARD
#define GRAPHMLWRITER_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439005
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include <LEDA/string.h>
#include <LEDA/graph.h>
#include <LEDA/list.h>
#include <LEDA/stream.h>
#include <LEDA/dictionary.h>

#include "GraphML_graph.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

/*{\Manpage{GraphML_writer}{}{Export}{gm}
}*/
class GraphML_writer:
public virtual GraphML_graph{
  /*{\Mdefinition
|\Mname| extends |GraphML_graph| and thus inherits from
|graphml_attributes<string>|, |graphml_parseinfo<string>|
and |graphml_structure<string>|.
An instance |\Mvar| of |\Mname| is a data structure that holds 
references to a |graph| and associated |node_| and 
|edge_array|s, and allows to export the referenced graph
and its attributes in GraphML format.  

Any of the following types may be used for attribute data: |bool|,
|int|, |long|, |float|, |double|, or |string| (i.e.\ |leda_string|). 
Types are identified by instances of 
\begin{quote}
|\Mname::gm_data_type|\\
| = \{bool_data, int_data, long_data, float_data, double_data,
string_data\}|.
\end{quote}

When exporting a graph referred to by |\Mvar| to a GraphML
document, the document type may be specified either using the 
GraphML Schema specification (recommended), or 
the GraphML Document Type Definition (DTD).
The specification method is identified by an instance of 
\begin{quote}
|\Mname::gm_specification_method|\\
| = \{no_spec, schema_spec, dtd_spec\}|.
\end{quote}

Meta-information for light-weight parsers is added upon request.
    }*/


 public:


  enum gm_specification_type{no_spec, schema_spec, dtd_spec};

  /*{\Mcreation 1}*/
  GraphML_writer(graph& G);
  /*{\Mcreate
    creates an instance |\Mvar| of type |\Mname| for graph |G|.
    }*/

  ~GraphML_writer();


  /*{\Moperations 1 1}*/



  void write(ostream& out, gm_specification_type spec_type, bool write_parseinfo = false);
  /*{\Mop
    Exports |\Mvar| to stream |out| in GraphML format.
    Argument |spec_type| indicates the document type specification 
    method to be included in the exported document:
    XML Schema specification, DTD or no specification.
    }*/

  bool write(string filename, gm_specification_type spec_type, bool write_parseinfo = false);
  /*{\Mop
    Exports |\Mvar| to file |filename| in GraphML format.
    Returns |true| if and only if the operation was completed 
    successfully.  
    Argument |spec_type| indicates the document type specification 
    method to be included in the exported document:
    XML Schema specification, DTD or no specification.
    }*/


 private:


  void writeSchemaLocation(ostream& out, bool write_parseinfo);

  void writeKeys(ostream& out);

  void writeKey(ostream& out, NodeData& nd);

  void writeDesc(ostream& out, NodeData& nd);

  void writeKey(ostream& out, EdgeData& ed);

  void writeDesc(ostream& out, EdgeData& ed);

  void writeDefault(ostream& out, string data);

  void writeGraph(ostream& out, bool write_parseinfo);

  void writeNode(ostream& out, unsigned int count, node v, bool write_parseinfo);

  void writeNodeData(ostream& out, node v);

  void writeEdge(ostream& out, unsigned int source, unsigned int target, edge e);

  void writeEdgeData(ostream& out, edge e);

  void writeIndent(ostream& out, unsigned int treedepth);

  const string beginStartTag(const string& elementName);

  const string endTag(const string& elementName);

  const string closeTag();

  //helper methods
  template<typename T>
    static string num2string(T number){
    string_ostream os;
    os << number << ends;
    return os.str();
  }


  static string bool2string(bool b);

  static string escape_chars(const string &str);

};

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE

#if LEDA_ROOT_INCL_ID == 439005
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif

