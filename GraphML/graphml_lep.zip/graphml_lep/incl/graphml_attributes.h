#ifndef GRAPHMLATTRIBUTES_HEADER_GUARD
#define GRAPHMLATTRIBUTES_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439006
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include "graphml_structure.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

/*{\Manpage{graphml_attributes}{T}{Attributes Extension}{gm}
}*/
/*{\Moptions constref=yes}*/
template<typename T>
class graphml_attributes:
virtual public graphml_structure<T>{//jlr
  /*{\Mdefinition
|\Mname| extends |graphml_structure<T>| by additionally providing 
access to local and qualified names of attributes added to GraphML 
elements in the GraphML Attributes Extension (as defined in XML Schema
[[graphml-attributes.xsd]]).  
  }*/

private:

  const T KEY_NAME;
  const T KEY_TYPE;

  const T KEY_TYPE_INT;
  const T KEY_TYPE_LONG;
  const T KEY_TYPE_FLOAT;
  const T KEY_TYPE_DOUBLE;
  const T KEY_TYPE_STRING;
  const T KEY_TYPE_BOOLEAN;


public:

  /*{\Mcreation 1}*/

  graphml_attributes():
    KEY_NAME("attr.name"),
    KEY_TYPE("attr.type"),
    KEY_TYPE_INT("int"),
    KEY_TYPE_LONG("long"),
    KEY_TYPE_FLOAT("float"),
    KEY_TYPE_DOUBLE("double"),
    KEY_TYPE_STRING("string"),
    KEY_TYPE_BOOLEAN("boolean")
  {}
  /*{\Mcreate
creates an instance |\Mvar| of type |\Mname|.
\\PRECONDITION:\\
Template parameter |T| must implement a constructor |T(const char*)|
and provide binary operators |+| (for concatenation) and |==|
(for equality testing).
  }*/


  ~graphml_attributes(){}


  /*{\Moperations 1 1}*/

  const T& key_name(){
    return KEY_NAME;
  }
  /*{\Mop
returns [["attr.name"]], i.e.\ the name of the optional attribute 
of element [[<key>]] that is used to give a human-readable 
name to data attributes.
    }*/

  const T& key_type(){
    return KEY_TYPE;
  }
  /*{\Mop
returns  [["attr.type"]], i.e.\ the name of the optional attribute
of element [[<key>]] that declares the elementary type of attribute data. 
    }*/


  const T& key_type_int(){
    return KEY_TYPE_INT;
  }
  /*{\Mop
returns [["int"]], i.e.\ the value representing the ``integer'' type in
the enumeration of all elementary data types supported in
the GraphML Attributes Extension.
    }*/
  /*{\Mtext
Methods
|key_type_boolean|,
|key_type_long|,
|key_type_float|,
|key_type_double|, and
|key_type_string|
have the same meaning accordingly.
  }*/

  const T& key_type_long(){
    return KEY_TYPE_LONG;
  }

  const T& key_type_float(){
    return KEY_TYPE_FLOAT;
  }

  const T& key_type_double(){
    return KEY_TYPE_DOUBLE;
  }

  const T& key_type_string(){
    return KEY_TYPE_STRING;
  }

  const T& key_type_boolean(){
    return KEY_TYPE_BOOLEAN;
  }

};
#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE


#if LEDA_ROOT_INCL_ID == 439006
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif
