#ifndef GRAPHMLREADER_HEADER_GUARD
#define GRAPHMLREADER_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439004
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include <LEDA/string.h>
#include <LEDA/graph.h>
#include <LEDA/list.h>
#include <LEDA/dictionary.h>

#include "GraphML_graph.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

/*{\Manpage{GraphML_reader}{}{Import}{gm}
}*/
class GraphML_reader:
public virtual GraphML_graph{
  /*{\Mdefinition
|\Mname| extends |GraphML_graph| and thus inherits from
|graphml_attributes<string>|, |graphml_parseinfo<string>|
and |graphml_structure<string>|.
An instance |\Mvar| of |\Mname| is a data structure that holds 
references to a |graph| and associated |node_| and 
|edge_array|s, and allows to import the referenced graph
and its attributes in GraphML format.  

Any of the following types may be used for attribute data: |bool|,
|int|, |long|, |float|, |double|, or |string| (i.e.\ |leda_string|). 
Types are identified by instances of 
\begin{quote}
|\Mname::gm_data_type|\\
| = \{bool_data, int_data, long_data, float_data, double_data,
string_data\}|.
\end{quote}

    }*/


 public:

  /*{\Mcreation 1}*/
  GraphML_reader(graph& G);
  /*{\Mcreate
    creates an instance |\Mvar| of type |\Mname| for graph |G|.
    }*/

  ~GraphML_reader();


  /*{\Moperations 1 1}*/




  bool read(string filename);
  /*{\Mop
    Imports a GraphML document from file |filename|.\\
    If |filename| is "-", imports a GraphML document from StdIn.\\
    Returns |true| if and only if the operation was completed
    successfully.\\
    Calls first |G.clear()| on the referenced graph |G|
    of |\Mvar|\\ 
    PRECONDITION:\\
    |filename| must contain a valid GraphML document 
    (validity will not be checked).
    }*/


 private:

};
#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE

#if LEDA_ROOT_INCL_ID == 439004
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif
