#ifndef GRAPHMLGRAPH_HEADER_GUARD
#define GRAPHMLGRAPH_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439002
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include <LEDA/string.h>
#include <LEDA/graph.h>
#include <LEDA/list.h>
#include <LEDA/dictionary.h>

#include "graphml_parseinfo.h"
#include "graphml_attributes.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

class EdgeData;
class NodeData;


/*{\Manpage{GraphML_graph}{}{Attributed Graphs}{gm}
}*/
class GraphML_graph:
public graphml_parseinfo<string>,
public graphml_attributes<string>{
  /*{\Mdefinition
|\Mname| extends both
|graphml_attributes<string>| and |graphml_parseinfo<string>|,
and thus inherits from |graphml_structure<string>|.
An instance |\Mvar| of |\Mname| is a data structure that holds 
references to a |graph| and associated |node_| and 
|edge_array|s.

Any of the following types may be used for attribute data: 
|int|, |long|, |float|, |double|, |string| (i.e.\ |leda_string|), 
or |bool|.  Types are identified by instances of 
\begin{quote}
|\Mname::gm_data_type = |\\
\qquad|\{bool_data, int_data, long_data, float_data, double_data,
string_data\}|.
\end{quote}

}*/


 public:

  /*{\Mtypes  }*/
  typedef int gm_handle_type;
  /*{\Mtypemember
    type for data handles (references to arrays of attribute data)
  }*/


  enum gm_data_type{bool_data, int_data, long_data, float_data, double_data, string_data};







  /*{\Mcreation 1}*/


  GraphML_graph(graph& G);
  /*{\Mcreate
    creates an instance |\Mvar| of type |\Mname| for graph |G|.
    }*/

  ~GraphML_graph();


  /*{\Moperations 1 1}*/



  /*{\Mtext
    \headerline{adding attribute data}
    }*/

  template<typename T> 
    gm_handle_type new_data(string name, gm_data_type type, node_array<T>& data, T default_value, string desc){
    NodeData n_data(data_handle, name, type, data, default_value, desc);
    nodeDataDict.insert(data_handle, n_data);
    return data_handle++;
  }
  /*{\Mop
    adds a new node attribute to |\Mvar|, and returns
    a handle which identifies this attribute and can be
    used as argument for |del_node_data|.
    \\
    PRECONDITION:\\
    Template parameter |T| must match |type|.
    }*/


  template<typename T> 
    gm_handle_type new_data(string name, gm_data_type type, edge_array<T>& data, T default_value, string desc){
    EdgeData e_data(data_handle, name, type, data, default_value, desc);
    edgeDataDict.insert(data_handle, e_data);
    return data_handle++;
  } 
  /*{\Mop
    adds a new edge attribute to |\Mvar|, and returns
    a handle that identifies this attribute and can be
    used as argument for |del_edge_data|.
    \\
    PRECONDITION:\\
    Template parameter |T| must match |type|.
    }*/


  /*{\Mtext
    \headerline{accessing attribute data}
    }*/

  list<gm_handle_type> node_data_handles();
  /*{\Mop
    returns the list of handles 
    for all node attributes referenced by |\Mvar|.
    }*/

  list<gm_handle_type> edge_data_handles();
  /*{\Mop
    returns the list of handles 
    for all edge attributes referenced by |\Mvar|.
    }*/

  /*{\Mtext
The following methods check whether their argument is
a valid node data handle.  In case it is not, the LEDA |error_handler|
is invoked.  These tests can be turned off using flag
[[-DLEDA_CHECKING_OFF]] during compilation.
  }*/

  gm_data_type data_type(gm_handle_type handle);
  /*{\Mop
    returns the data type of the attribute identified by |handle|.
    }*/

  string data_name(gm_handle_type handle);
  /*{\Mop
    returns the name of the attribute identified by |handle|.
    }*/

  string data_desc(gm_handle_type handle);
  /*{\Mop
    returns the description of the attribute identified by |handle|.
    }*/

  template<typename T> node_array<T>& node_data(gm_handle_type handle);
  /*{\Mop
    returns the array of values of the attribute identified by 
    |handle|.\\
    PRECONDITION:\\
    |handle| is a valid \emph{node} data handle.
    This template is implemented only for types |bool|, |int|, |long|, 
    |float|, |double|, and |string|.
    }*/

  template<typename T> edge_array<T>& edge_data(gm_handle_type handle);
  /*{\Mop
    returns the array of values of the attribute identified by 
    |handle|.\\
    PRECONDITION:\\
    |handle| is a valid \emph{edge} data handle.
    This template is implemented only for types |bool|, |int|, |long|, 
    |float|, |double|, and |string|.
    }*/

  template<typename T> T& data_default(gm_handle_type handle);
  /*{\Mop
    returns the default value of the attribute identified by |handle|.
    This template is implemented only for types |bool|, |int|, |long|, 
    |float|, |double|, and |string|.
    }*/


  /*{\Mtext
    \headerline{removing attribute data}
    }*/
  bool del_data(gm_handle_type handle);
  /*{\Mop
    removes the references to a data attribute 
    (identified by |handle|) from |\Mvar|.
    Returns true if and only if the removal has been successful
    (i.e.\ |handle| corresponds to an existing data attribute).
    }*/


 protected:

  //  handle_type data_handle;
  gm_handle_type data_handle;//jlr



  //mapping from data-handles to node-attributes
  //  dictionary<handle_type, NodeData> nodeDataDict; 
  dictionary<gm_handle_type, NodeData> nodeDataDict; 



  //mapping from data-handles to edge-attributes
  //  dictionary<handle_type, EdgeData> edgeDataDict;
  dictionary<gm_handle_type, EdgeData> edgeDataDict;


  //holds the core graph structure (nodes and edges)
  graph& G;

};


//datastructure for node-attributes
class NodeData{
 public:

  GraphML_graph::gm_handle_type id;
  string name;
  GraphML_graph::gm_data_type type;

  node_array<bool> nd_bool;
  node_array<int> nd_int;
  node_array<long> nd_long;
  node_array<float> nd_float;
  node_array<double> nd_double;
  node_array<string> nd_string;
  
  int int_default;
  long long_default;
  float float_default;
  double double_default;
  string string_default;
  bool bool_default;

  string desc;


  NodeData();

  NodeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_array<int>& d, int def, string des);

  NodeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_array<long>& d, long def, string des);

  NodeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_array<float>& d, float def, string des);

  NodeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_array<double>& d, double def, string des);

  NodeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_array<string>& d, string def, string des);

  NodeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_array<bool>& d, bool def, string des);

  bool hasDefaultData(node v);

};


//datastructure for edge-attributes
class EdgeData{
 public:

  GraphML_graph::gm_handle_type id;
  string name;
  GraphML_graph::gm_data_type type;

  edge_array<bool> ed_bool;
  edge_array<int> ed_int;
  edge_array<long> ed_long;
  edge_array<float> ed_float;
  edge_array<double> ed_double;
  edge_array<string> ed_string;
  
  int int_default;
  long long_default;
  float float_default;
  double double_default;
  string string_default;
  bool bool_default;

  string desc;

  EdgeData();

  EdgeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_array<int>& d, int def, string des);

  EdgeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_array<long>& d, long def, string des);

  EdgeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_array<float>& d, float def, string des);

  EdgeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_array<double>& d, double def, string des);

  EdgeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_array<string>& d, string def, string des);

  EdgeData(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_array<bool>& d, bool def, string des);

  bool hasDefaultData(edge e);

};

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE


#if LEDA_ROOT_INCL_ID == 439002
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif
