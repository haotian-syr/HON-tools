#ifndef GRAPHMLPARSEINFO_HEADER_GUARD
#define GRAPHMLPARSEINFO_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439007
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include "graphml_structure.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

/*{\Manpage{graphml_parseinfo}{T}{Parse Extension}{gm}
}*/
/*{\Moptions constref=yes}*/
template<typename T>
class graphml_parseinfo:
virtual public graphml_structure<T>{//jlr
  /*{\Mdefinition
|\Mname| extends |graphml_structure<T>| by additionally providing 
access to local and qualified names of attributes added to GraphML
elements in the GraphML Parse Extension (as defined in XML Schema
[[graphml-parseinfo.xsd]]). 
  }*/

private:

  const T GRAPH_NODEIDS;
  const T GRAPH_EDGEIDS;
  const T GRAPH_ORDER;
  const T GRAPH_NODES;
  const T GRAPH_EDGES;
  const T GRAPH_MAXINDEGREE;
  const T GRAPH_MAXOUTDEGREE;
  const T NODE_INDEGREE;
  const T NODE_OUTDEGREE;

  const T GRAPH_NODEIDS_CANONICAL;
  const T GRAPH_EDGEIDS_CANONICAL;
  const T GRAPH_ORDER_FREE;
  const T GRAPH_ORDER_NODESFIRST;
  const T GRAPH_ORDER_ADJACENCYLIST;



public:

  /*{\Mcreation 1}*/

  graphml_parseinfo():
    GRAPH_NODEIDS("parse.nodeids"),
    GRAPH_EDGEIDS("parse.edgeids"),
    GRAPH_ORDER("parse.order"),
    GRAPH_NODES("parse.nodes"),
    GRAPH_EDGES("parse.edges"),
    GRAPH_MAXINDEGREE("parse.maxindegree"),
    GRAPH_MAXOUTDEGREE("parse.maxoutdegree"),
    NODE_INDEGREE("parse.indegree"),
    NODE_OUTDEGREE("parse.outdegree"),
    GRAPH_NODEIDS_CANONICAL("canonical"),
    GRAPH_EDGEIDS_CANONICAL("canonical"),
    GRAPH_ORDER_FREE("free"),
    GRAPH_ORDER_NODESFIRST("nodesfirst"),
    GRAPH_ORDER_ADJACENCYLIST("adjacencylist")
    {}
  /*{\Mcreate
    creates an instance |\Mvar| of type |\Mname|.
\\PRECONDITION:\\
Template parameter |T| must implement a constructor |T(const char*)|
and provide binary operators |+| (for concatenation) and |==|
(for equality testing).
    }*/


  ~graphml_parseinfo(){}


  /*{\Moperations 1 1}*/

  /*{\Mtext
\headerline{attribute names}
  }*/

  const T& graph_nodeids(){
    return GRAPH_NODEIDS;
  }
  /*{\Mop
returns [["nodeids"]], i.e.\ the name of the optional attribute
of GraphML element [[<graph>]] that can be used to specify an order
in which nodes and edges are encountered in the GraphML document.
    }*/
  /*{\Mtext
Methods |graph_edgeids|, |graph_order|, |graph_nodes|, |graph_edges|, 
|graph_maxindegree|, |graph_maxoutdegree|, |node_indegree|, and 
|node_outdegree| have the same meaning accordingly. 
  }*/

  const T& graph_edgeids(){
    return GRAPH_EDGEIDS;
  }
  const T& graph_order(){
    return GRAPH_ORDER;
  }
  const T& graph_nodes(){
    return GRAPH_NODES;
  }
  const T& graph_edges(){
    return GRAPH_EDGES;
  }
  const T& graph_maxindegree(){
    return GRAPH_MAXINDEGREE;
  }
  const T& graph_maxoutdegree(){
    return GRAPH_MAXOUTDEGREE;
  }
  const T& node_indegree(){
    return NODE_INDEGREE;
  }
  const T& node_outdegree(){
    return NODE_OUTDEGREE;
  }

  const T& graph_nodeids_canonical(){
    return GRAPH_NODEIDS_CANONICAL;
  }
  /*{\Mop
returns [["canonical"]], i.e.\ the value of attribute 
[[nodeids]] of GraphML element [[<graph>]] indicating that all node IDs
are of the form \texttt{v}$i$, where $i$ is the number of the node
and all nodes are numbered consecutively (starting with zero).
    }*/
  /*{\Mtext
Methods |graph_edgeids_canonical|, |graph_order_free|, 
|graph_order_nodesfirst|, and |graph_order_adjacencylist| 
have the same meaning accordingly. 
  }*/
  const T& graph_edgeids_canonical(){
    return GRAPH_EDGEIDS_CANONICAL;
  }
  const T& graph_order_free(){
    return GRAPH_ORDER_FREE;
  }
  const T& graph_order_nodesfirst(){
    return GRAPH_ORDER_NODESFIRST;
  }
  const T& graph_order_adjacencylist(){
    return GRAPH_ORDER_ADJACENCYLIST;
  }
};

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE

#if LEDA_ROOT_INCL_ID == 439007
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif
