#ifndef GRAPHMLSTRUCTURE_HEADER_GUARD
#define GRAPHMLSTRUCTURE_HEADER_GUARD

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439008
#include <LEDA/REDEFINE_NAMES.h>
#endif

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

/*{\Manpage{graphml_structure}{T}{Structural Layer}{gm}
}*/
/*{\Moptions constref=yes}*/
template<typename T>
class graphml_structure{
  /*{\Mdefinition
An instance |\Mvar| of |\Mname| provides access to local
and qualified names of those elements and attributes that make up the 
structural layer of GraphML (as defined in XML Schema 
[[graphml-structure.xsd]]).  
  }*/

private:
  bool prefixed;
  const T GRAPHML_NS_URI;
  T GRAPHML_PREFIX;
  T XLINK_PREFIX;

  //local names of GraphML elements
  const T GRAPHML_GRAPHML;
  const T GRAPHML_KEY;
  const T GRAPHML_DEFAULT;
  const T GRAPHML_DATA;
  const T GRAPHML_GRAPH;
  const T GRAPHML_NODE;
  const T GRAPHML_PORT;
  const T GRAPHML_EDGE;
  const T GRAPHML_HYPEREDGE;
  const T GRAPHML_ENDPOINT;
  const T GRAPHML_LOCATOR;
  const T GRAPHML_DESC;

  //attribute names
  const T KEY_ID;
  const T KEY_FOR;
  const T DATA_KEY;
  const T DATA_ID;
  const T GRAPH_ID;
  const T GRAPH_EDGEDEFAULT;
  const T NODE_ID;
  const T PORT_NAME;
  const T EDGE_ID;
  const T EDGE_DIRECTED;
  const T EDGE_SOURCE;
  const T EDGE_TARGET;
  const T EDGE_SOURCEPORT;
  const T EDGE_TARGETPORT;
  const T HYPEREDGE_ID;
  const T ENDPOINT_ID;
  const T ENDPOINT_PORT;
  const T ENDPOINT_NODE;
  const T ENDPOINT_TYPE;
  const T LOCATOR_HREF;
  const T LOCATOR_TYPE;


  const T EMPTYSTRING;

  //qualified names of GraphML elements
  T GRAPHML_QN;
  T KEY_QN;
  T DEFAULT_QN;
  T DATA_QN;
  T GRAPH_QN;
  T NODE_QN;
  T PORT_QN;
  T EDGE_QN;
  T HYPEREDGE_QN;
  T ENDPOINT_QN;
  T LOCATOR_QN;
  T DESC_QN;



public:
  T XML_DECL; //jlr
  T DOCTYPE_DECL;//jlr
  T SCHEMA_LOCATION;//jlr
  const T XSI_PREFIX;//jlr

  const T COLON;

  //graphml_structure(T (*f)(T*,T)):
  /*{\Mcreation 1}*/
  graphml_structure():
  /*{\Mcreate
creates an instance |\Mvar| of type |\Mname|.
\\PRECONDITION:\\
Template parameter |T| must implement a constructor |T(const char*)|
and provide binary operators |+| (for concatenation) and |==| 
(for equality testing).
  }*/
    prefixed(false),
    GRAPHML_NS_URI("http://graphml.graphdrawing.org/xmlns/1.0rc"),
    GRAPHML_PREFIX(""),
    XLINK_PREFIX("xlink"),
    GRAPHML_GRAPHML("graphml"),
    GRAPHML_KEY("key"),
    GRAPHML_DEFAULT("default"),
    GRAPHML_DATA("data"),
    GRAPHML_GRAPH("graph"),
    GRAPHML_NODE("node"),
    GRAPHML_PORT("port"),
    GRAPHML_EDGE("edge"),
    GRAPHML_HYPEREDGE("hyperedge"),
    GRAPHML_ENDPOINT("endpoint"),
    GRAPHML_LOCATOR("locator"),
    GRAPHML_DESC("desc"),
    KEY_ID("id"),
    KEY_FOR("for"),
    DATA_KEY("key"),
    DATA_ID("id"),
    GRAPH_ID("id"),
    GRAPH_EDGEDEFAULT("edgedefault"),
    NODE_ID("id"),
    PORT_NAME("name"),
    EDGE_ID("id"),
    EDGE_DIRECTED("directed"),
    EDGE_SOURCE("source"),
    EDGE_TARGET("target"),
    EDGE_SOURCEPORT("sourceport"),
    EDGE_TARGETPORT("targetport"),
    HYPEREDGE_ID("id"),
    ENDPOINT_ID("id"),
    ENDPOINT_PORT("port"),
    ENDPOINT_NODE("node"),
    ENDPOINT_TYPE("type"),
    LOCATOR_HREF("href"),
    LOCATOR_TYPE("type"),
    EMPTYSTRING(""),
    XML_DECL("<?xml version=\"1.0\"?>"),
    DOCTYPE_DECL("<!DOCTYPE graphml SYSTEM \"graphml.dtd\">"),
    SCHEMA_LOCATION("http://graphml.graphdrawing.org/xmlns/1.0rc\n                    graphml-structure-1.0rc.xsd\n\n        	    http://graphml.graphdrawing.org/xmlns/1.0rc\n                    graphml-attributes-1.0rc.xsd"),
    XSI_PREFIX("xsi"),
    COLON(":")
    {
      set_graphml_prefix(GRAPHML_PREFIX);
    }


  ~graphml_structure(){}


  /*{\Moperations 1 1}*/

  const T& get_xml_decl(){
    return XML_DECL;
  }
  /*{\Mop
returns the XML declaration string used when exporting |\Mvar|.
Default value is [[<?xml version="1.0"?>]].
    }*/

  void set_xml_decl(T decl){
    XML_DECL = decl;
  }
  /*{\Mop
sets the XML declaration string to |decl|.
    }*/

  T& get_doctype_decl(){
  return DOCTYPE_DECL;
}
  /*{\Mop
returns the document type declaration inserted when exporting |\Mvar| 
using XML Document Type Definition (DTD) for type specification.
Default value is [[http://graphml.graphdrawing.org/dtds/1.0rc/graphml.dtd]].
    }*/

  void set_doctype_decl(T decl){
  DOCTYPE_DECL = decl;
}
  /*{\Mop
sets the document type declaration string to |decl|.
    }*/

  const T& get_schema_loc(){
  return SCHEMA_LOCATION;
}
  /*{\Mop
   returns the value given to attribute [[schemaLocation]] when 
   exporting |\Mvar| using XML Schema for type specification.
   Default value is
   [[http://graphml.graphdrawing.org/xmlns/1.0rc graphml-structure-1.0rc.xsd]]
    }*/

  void set_schema_loc(T loc){
  SCHEMA_LOCATION = loc;
}
  /*{\Mop
sets the XML Schema location string to |loc|.
    }*/


  bool is_prefixed(){
    return prefixed;
  }
  /*{\Mop
    returns |true| if and only if the GraphML namespace prefix is
    not empty.
    }*/


  const T& get_graphml_prefix(){
    return GRAPHML_PREFIX;
  }
  /*{\Mop
    returns the GraphML namespace prefix used 
    with qualified GraphML element names.
    }*/

  void set_graphml_prefix(T pfx){
    T sep;
    if(pfx == EMPTYSTRING){
      prefixed = false;
      GRAPHML_PREFIX = EMPTYSTRING;
      sep = EMPTYSTRING;
    }
    else{
      prefixed = true;
      GRAPHML_PREFIX = pfx;
      sep = COLON;
    }
    GRAPHML_QN   = GRAPHML_PREFIX + sep + GRAPHML_GRAPHML;
    KEY_QN       = GRAPHML_PREFIX + sep + GRAPHML_KEY;
    DEFAULT_QN   = GRAPHML_PREFIX + sep + GRAPHML_DEFAULT;
    DATA_QN      = GRAPHML_PREFIX + sep + GRAPHML_DATA;
    GRAPH_QN     = GRAPHML_PREFIX + sep + GRAPHML_GRAPH;
    NODE_QN      = GRAPHML_PREFIX + sep + GRAPHML_NODE;
    PORT_QN      = GRAPHML_PREFIX + sep + GRAPHML_PORT;
    EDGE_QN      = GRAPHML_PREFIX + sep + GRAPHML_EDGE;
    HYPEREDGE_QN = GRAPHML_PREFIX + sep + GRAPHML_HYPEREDGE;
    ENDPOINT_QN  = GRAPHML_PREFIX + sep + GRAPHML_ENDPOINT;
    LOCATOR_QN   = GRAPHML_PREFIX + sep + GRAPHML_LOCATOR;
    DESC_QN      = GRAPHML_PREFIX + sep + GRAPHML_DESC;    
  }
  /*{\Mop
sets the GraphML namespace prefix to |pfx| and updates all
qualified GraphML element names accordingly.
    }*/


  const T& get_xlink_prefix(){
    return XLINK_PREFIX;
  }
  /*{\Mop
    returns the XLink namespace prefix used with the XLink attributes
    of GraphML element [[<locator>]].
    }*/

  void set_xlink_prefix(T pfx){
    XLINK_PREFIX = pfx;
  }
  /*{\Mop
sets the XLink namespace prefix to |pfx|. 
    }*/


  const T& ns_uri(){
    return GRAPHML_NS_URI;
  }
  /*{\Mop
returns [[http://graphml.graphdrawing.org/xmlns/1.0rc]], i.e.\ the 
GraphML namespace URI of GraphML Version~1.0rc (on which this package
is based).
    }*/


  /*{\Mtext
\headerline{local element names}
  }*/
 
  const T& graphml_ln(){
    return GRAPHML_GRAPHML;
  }
  /*{\Mop
returns [["graphml"]], i.e.\ the local name of GraphML element 
[[<graphml>]].
    }*/
  /*{\Mtext
Methods 
|desc_ln|,
|key_ln|,
|default_ln|,
|data_ln|,
|graph_ln|,
|node_ln|,
|port_ln|,
|edge_ln|,
|hyperedge_ln|,
|endpoint_ln|, and
|locator_ln| have the same meaning accordingly.
  }*/

  const T& key_ln(){
    return GRAPHML_KEY;
  }

  const T& default_ln(){
    return GRAPHML_DEFAULT;
  }

  const T& data_ln(){
    return GRAPHML_DATA;
  }

  const T& graph_ln(){
    return GRAPHML_GRAPH;
  }

  const T& node_ln(){
    return GRAPHML_NODE;
  }

  const T& port_ln(){
    return GRAPHML_PORT;
  }

  const T& edge_ln(){
    return GRAPHML_EDGE;
  }

  const T& hyperedge_ln(){
    return GRAPHML_HYPEREDGE;
  }

  const T& endpoint_ln(){
    return GRAPHML_ENDPOINT;
  }

  const T& locator_ln(){
    return GRAPHML_LOCATOR;
  }

  const T& desc_ln(){
    return GRAPHML_DESC;
  }

  /*{\Mtext
\headerline{qualified element names}
  }*/

  const T& graphml_qn(){
    return GRAPHML_QN;
  }
  /*{\Mop
returns the qualified name of GraphML element [[<graphml>]].
    }*/
  /*{\Mtext
Methods 
|key_qn|,
|default_qn|,
|data_qn|,
|graph_qn|,
|node_qn|,
|port_qn|,
|edge_qn|,
|hyperedge_qn|,
|endpoint_qn|,
|locator_qn|, and
|desc_qn| have the same meaning accordingly.
  }*/

  const T& key_qn(){
    return KEY_QN;
  }

  const T& default_qn(){
    return DEFAULT_QN;
  }

  const T& data_qn(){
    return DATA_QN;
  }

  const T& graph_qn(){
    return GRAPH_QN;
  }

  const T& node_qn(){
    return NODE_QN;
  }

  const T& port_qn(){
    return PORT_QN;
  }

  const T& edge_qn(){
    return EDGE_QN;
  }

  const T& hyperedge_qn(){
    return HYPEREDGE_QN;
  }

  const T& endpoint_qn(){
    return ENDPOINT_QN;
  }

  const T& locator_qn(){
    return LOCATOR_QN;
  }

  const T& desc_qn(){
    return DESC_QN;
  }


  /*{\Mtext
\headerline{attribute names}
  }*/
 
  const T& key_id(){
    return KEY_ID;
  }
  /*{\Mop
returns [["id"]], i.e.\  the name of the attribute that identifies
a GraphML element [[<key>]].
    }*/
/*{\Mtext
Methods
|key_for|,
|data_key|,
|data_id|,
|graph_edgedefault|,
|node_id|,
|port_name|,
|edge_id|,
|edge_default|,
|edge_source|,
|edge_target|,
|edge_sourceport|,
|edge_targetport|,
|hyperedge_id|,
|endpoint_id|,
|endpoint_node|,
|endpoint_port|, and
|endpoint_type|
have the same meaning accordingly.
}*/
  const T& key_for(){
    return KEY_FOR;
  }

  const T& data_key(){
    return DATA_KEY;
  }

  const T& data_id(){
    return DATA_ID;
  }

  const T& graph_edgedefault(){
    return GRAPH_EDGEDEFAULT;
  }

  const T& node_id(){
    return NODE_ID;
  }

  const T& port_name(){
    return PORT_NAME;
  }

  const T& edge_id(){
    return EDGE_ID;
  }

  const T& edge_directed(){
    return EDGE_DIRECTED;
  }

  const T& edge_source(){
    return EDGE_SOURCE;
  }

  const T& edge_target(){
    return EDGE_TARGET;
  }

  const T& edge_sourceport(){
    return EDGE_SOURCEPORT;
  }

  const T& edge_targetport(){
    return EDGE_TARGETPORT;
  }

  const T& hyperedge_id(){
    return HYPEREDGE_ID;
  }

  const T& endpoint_id(){
    return ENDPOINT_ID;
  }

  const T& endpoint_port(){
    return ENDPOINT_PORT;
  }

  const T& endpoint_node(){
    return ENDPOINT_NODE;
  }

  const T& endpoint_type(){
    return ENDPOINT_TYPE;
  }

  const T& locator_href_ln(){
    return LOCATOR_HREF;
  }
  /*{\Mop
returns [["href"]], 
i.e.\ the \emph{local} attribute name for attribute [[href]] 
of GraphML element [[<locator>]].
For a GraphML document to be valid, this attribute is prefixed with
the XLink prefix followed by a colon.
    }*/

  const T& locator_type_ln(){
    return LOCATOR_TYPE;
  }
  /*{\Mop
returns [["type"]],
i.e.\ the \emph{local} attribute name for attribute [[type]]
of GraphML element [[<locator>]].
For a GraphML document to be valid, this attribute is prefixed with
the XLink prefix followed by a colon.
    }*/

};

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE

#if LEDA_ROOT_INCL_ID == 439008
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif
