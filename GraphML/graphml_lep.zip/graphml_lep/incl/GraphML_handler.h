#ifndef GRAPHMLHANDLER_HEADER_GUARD
#define GRAPHMLHANDLER_HEADER_GUARD

#include <xercesc/sax2/XMLReaderFactory.hpp>
#include <xercesc/sax2/DefaultHandler.hpp>

#if !defined(LEDA_ROOT_INCL_ID)
#define LEDA_ROOT_INCL_ID 439003
#include <LEDA/REDEFINE_NAMES.h>
#endif

#include <LEDA/string.h>
#include <LEDA/graph.h>
#include <LEDA/list.h>
#include <LEDA/dictionary.h>

#include "GraphML.h"


#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE
XERCES_CPP_NAMESPACE_USE

//data structures for node/edge-data
//during the parse process
class nd4p;
class ed4p;

//implementation of the Xerces DefaultHandler class

//used in graphml::read
class GraphML_handler : public DefaultHandler {

  graph &g;

  GraphML_reader &gr_leda;

  //mapping {node-id} --> {node}
  dictionary<string, node> nodeById;

  //mapping {key-id} --> {node-data}
  dictionary<string, nd4p*> nDataById;

  //current node-data
  nd4p *currentNData;

  //mapping {key-id} --> {edge-data}
  dictionary<string, ed4p*> eDataById;

  //current edge-data
  ed4p *currentEData;

  //...
  node currentNode;

  //...
  edge currentEdge;

  //prefixes for the GraphML namespace
  //(this is a list rather than one string because
  //prefixes might be changed for arbitrary subtrees
  //of the document tree)
  list<string> prefixes;

  //=============================================
  //variables describing the state of this Handler
  //=============================================
  //counts the number of <graph>...</graph> pairs
  //enclosing the current element
  unsigned int graph_level;

  //counts the top-level graphs
  unsigned int tlgraph_count;

  //true if and only if the parser is currently within a 
  //<default> element
  bool withinDefault;
  //true if and only if the parser is currently within a 
  //<data> element
  bool withinData;
  //true if and only if the parser is currently within a
  //<key> element
  bool withinKey;
  //true if and only if the parser is currently within a
  //<desc> element
  bool withinDesc;
  //true if and only if data means node-data
  bool nData;
  //true if and only if data means edge-data
  bool eData;
  //true if and only if the graph has edgedefault="undirected"
  bool undirected;

  //=============================================
  //returns true if and only if nodes and edges should be ignored
  bool ignore();

  //=============================================
  //specific methods called by the ContentHandlers 
  //methods
  //=============================================
  void startGraphMLElement(string q_name, const Attributes& attributes);

  void startGraphElement(const Attributes &attributes);

  void startKeyElement(const Attributes &attributes);

  void startDescElement();

  void startDefaultElement(const Attributes &attributes);

  void startDataElement(const Attributes &attributes);

  void startNodeElement(const Attributes &attributes);

  void startEdgeElement(const Attributes &attributes);

  void endGraphElement();

  void endKeyElement();

  void endDescElement();

  void endDefaultElement();

  void endDataElement();

  void endNodeElement();

  void endEdgeElement();

  string attributeValue(const Attributes &attributes, string qName);

  //helper methods
  static string xmlch2string(const XMLCh *xmlch);

  static bool xmlch2bool(const XMLCh *xmlch);

  static double xmlch2double(const XMLCh *xmlch);

  static float xmlch2float(const XMLCh *xmlch);

  static int xmlch2int(const XMLCh *xmlch);

  static long xmlch2long(const XMLCh *xmlch);


 public:

  GraphML_handler(graph &gr, GraphML_reader &gml);

  //==================================================
  //implementation of the ContentHandler interface
  //==================================================
  void startDocument();

  void endDocument();

  void startElement(const XMLCh* const uri,
         	    const XMLCh* const localname,
		    const XMLCh* const qname,
		    const Attributes& attributes);

  void endElement(const XMLCh* const uri,
		  const XMLCh* const localname,
		  const XMLCh* const qname);

  void characters (const XMLCh *const chars, const unsigned int length );

  void startPrefixMapping (const XMLCh *const prefix,const XMLCh *const uri);

  void endPrefixMapping (const XMLCh *const prefix);
};

//datastructure for node-data during the parse process
class nd4p{
 public:

  GraphML_graph::gm_handle_type id;
  string name;
  GraphML_graph::gm_data_type type;

  node_map<bool> value_specified;

  node_map<bool> nd_bool;
  node_map<int> nd_int;
  node_map<long> nd_long;
  node_map<float> nd_float;
  node_map<double> nd_double;
  node_map<string> nd_string;
  
  int int_default;
  long long_default;
  float float_default;
  double double_default;
  string string_default;
  bool bool_default;

  string desc;


  nd4p();

  nd4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_map<int>& d, int def, string des);

  nd4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_map<long>& d, long def, string des);

  nd4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_map<float>& d, float def, string des);

  nd4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_map<double>& d, double def, string des);

  nd4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_map<string>& d, string def, string des);

  nd4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, node_map<bool>& d, bool def, string des);

  bool hasDefaultData(node v);

};


//datastructure for edge-data
//during the parse process
class ed4p{
 public:

  GraphML_graph::gm_handle_type id;
  string name;
  GraphML_graph::gm_data_type type;

  edge_map<bool> value_specified;

  edge_map<bool> ed_bool;
  edge_map<int> ed_int;
  edge_map<long> ed_long;
  edge_map<float> ed_float;
  edge_map<double> ed_double;
  edge_map<string> ed_string;
  
  int int_default;
  long long_default;
  float float_default;
  double double_default;
  string string_default;
  bool bool_default;

  string desc;

  ed4p();

  ed4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_map<int>& d, int def, string des);

  ed4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_map<long>& d, long def, string des);

  ed4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_map<float>& d, float def, string des);

  ed4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_map<double>& d, double def, string des);

  ed4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_map<string>& d, string def, string des);

  ed4p(GraphML_graph::gm_handle_type i, string n, GraphML_graph::gm_data_type t, edge_map<bool>& d, bool def, string des);

  bool hasDefaultData(edge e);

};

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE


#if LEDA_ROOT_INCL_ID == 439003
#undef LEDA_ROOT_INCL_ID
#include <LEDA/UNDEFINE_NAMES.h>
#endif

#endif
