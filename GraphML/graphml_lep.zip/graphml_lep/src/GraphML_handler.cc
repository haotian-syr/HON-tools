#include "GraphML_handler.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

//======================================================
//helper methods
//=====================================================

//conversion from Xerces XMLCh * to leda_string
string GraphML_handler::xmlch2string(const XMLCh *xmlch){
  if(XMLString::stringLen(xmlch) > 0){
    char* s = XMLString::transcode(xmlch);
    string retVal = string(s);
    delete[] s;
    return retVal;
  }
  return string("");
} 

//conversion from Xerces XMLCh * to bool
//(returns false if the string is neither 
//'true' nor 'false') 
bool GraphML_handler::xmlch2bool(const XMLCh *xmlch){
  string s = xmlch2string(xmlch);
  s = s.del_all(string(" "));
  string true_str("true");
  string false_str("false");
  if(s == true_str){
    return true;
  }
  if(s == false_str){
    return false;
  }
  //  cout << "xmlch2bool : neither true nor false" << endl;
  return false;
} 


//conversion from Xerces XMLCh * to the different 
//number types
double GraphML_handler::xmlch2double(const XMLCh *xmlch){
  char* s = XMLString::transcode(xmlch);
  double retVal = atof(s);
  delete[] s;
  return retVal;
}
float GraphML_handler::xmlch2float(const XMLCh *xmlch){
  char* s = XMLString::transcode(xmlch);
  float retVal = atof(s);
  delete[] s;
  return retVal;
}
int GraphML_handler::xmlch2int(const XMLCh *xmlch){
  char* s = XMLString::transcode(xmlch);
  int retVal = atoi(s);
  delete[] s;
  return retVal;
}
long GraphML_handler::xmlch2long(const XMLCh *xmlch){
  char* s = XMLString::transcode(xmlch);
  long retVal = atol(s);
  delete[] s;
  return retVal;
}

//returns the value (as a leda_string) of the attribute
//identified by 'qName' (as it occurs in attributes)
string GraphML_handler::attributeValue(const Attributes &attributes, string qName){
  XMLCh* xmlch = XMLString::transcode(qName);
  string retVal = xmlch2string(attributes.getValue(xmlch));
  delete[] xmlch;
  return retVal;
}
//===========================================================
//===========================================================


GraphML_handler::GraphML_handler(graph &gr, GraphML_reader &gml):
  g(gr),
  gr_leda(gml),
  graph_level(0),
  tlgraph_count(0),
  withinDefault(false),
  withinData(false),
  withinKey(false),
  withinDesc(false),
  nData(false),
  eData(false),
  undirected(false)
{}

void GraphML_handler::startDocument(){
  tlgraph_count = 0;
}

void GraphML_handler::endDocument(){}

void GraphML_handler::startElement(const XMLCh* const uri,
				   const XMLCh* const localname,
				   const XMLCh* const qname,
				   const Attributes& attributes){
  string ns_uri = xmlch2string(uri);
  string l_name = xmlch2string(localname);
  string q_name = xmlch2string(qname);
  //handle the case of l_name = graphml differently, because
  //the namespace prefix is not yet known ????
  if((ns_uri == gr_leda.ns_uri()) || 
     (l_name == gr_leda.graphml_ln())){
    startGraphMLElement(q_name, attributes);
  } 
  //call the corresponding methods
  if(q_name == gr_leda.graph_qn()){
    startGraphElement(attributes);
  }
  if(q_name == gr_leda.key_qn()){
    startKeyElement(attributes);
  }
  if(q_name == gr_leda.default_qn()){
    startDefaultElement(attributes);
  }
  if(q_name == gr_leda.data_qn()){
    startDataElement(attributes);
  }
  if(q_name == gr_leda.node_qn()){
    startNodeElement(attributes);
  }
  if(q_name == gr_leda.edge_qn()){
    startEdgeElement(attributes);
  }
  if(q_name == gr_leda.desc_qn()){
    startDescElement();
  }
}

void GraphML_handler::endElement(const XMLCh* const uri,
				 const XMLCh* const localname,
				 const XMLCh* const qname){

  string q_name = xmlch2string(qname);
  //call the corresponding methods
  if(q_name == gr_leda.graph_qn()){
    endGraphElement();
  }
  if(q_name == gr_leda.key_qn()){
    endKeyElement();
  }
  if(q_name == gr_leda.default_qn()){
    endDefaultElement();
  }
  if(q_name == gr_leda.data_qn()){
    endDataElement();
  }
  if(q_name == gr_leda.node_qn()){
    endNodeElement();
  }
  if(q_name == gr_leda.edge_qn()){
    endEdgeElement();
  }
  if(q_name == gr_leda.desc_qn()){
    endDescElement();
  }
}
//only character data between <default> and <data> elements 
//which is data for <node>s or <edge>s 
//or descriptions for keys
//will be processed
void GraphML_handler::characters (const XMLCh *const chars, const unsigned int length ){
  if((withinDefault || withinData)&&(nData || eData)){
    int type;
    if(nData){
      type = currentNData->type;
    }
    if(eData){
      type = currentEData->type;
    }

    int int_value;
    long long_value;
    float float_value;
    double double_value;
    string string_value;
    bool boolean_value;
    switch(type){
    case GraphML::int_data:
      int_value = xmlch2int(chars);
      if(withinDefault){
	if(nData){
	  currentNData->int_default = int_value;
	}
	if(eData){
	  currentEData->int_default = int_value;
	}
      }
      if(withinData){
	if(nData){
	  (currentNData->nd_int)[currentNode] = int_value;
	  (currentNData->value_specified)[currentNode] = true;
	}
	if(eData){
	  (currentEData->ed_int)[currentEdge] = int_value;
	  (currentEData->value_specified)[currentEdge] = true;
	}
      }
      break;
    case GraphML::long_data:
      long_value = xmlch2long(chars);
      if(withinDefault){
	if(nData){
	  currentNData->long_default = long_value;
	}
	if(eData){
	  currentEData->long_default = long_value;
	}
      }
      if(withinData){
	if(nData){
	  (currentNData->nd_long)[currentNode] = long_value;
	  (currentNData->value_specified)[currentNode] = true;
	}
	if(eData){
	  (currentEData->ed_long)[currentEdge] = long_value;
	  (currentEData->value_specified)[currentEdge] = true;
	}
      }
      break;
    case GraphML::float_data:
      float_value = xmlch2float(chars);
      if(withinDefault){
	if(nData){
	  currentNData->float_default = float_value;
	}
	if(eData){
	  currentEData->float_default = float_value;
	}
      }
      if(withinData){
	if(nData){
	  (currentNData->nd_float)[currentNode] = float_value;
	  (currentNData->value_specified)[currentNode] = true;
	}
	if(eData){
	  (currentEData->ed_float)[currentEdge] = float_value;
	  (currentEData->value_specified)[currentEdge] = true;
	}
      }
      break;
    case GraphML::double_data:
      double_value = xmlch2double(chars);
      if(withinDefault){
	if(nData){
	  currentNData->double_default = double_value;
	}
	if(eData){
	  currentEData->double_default = double_value;
	}
      }
      if(withinData){
	if(nData){
	  (currentNData->nd_double)[currentNode] = double_value;
	  (currentNData->value_specified)[currentNode] = true;
	}
	if(eData){
	  (currentEData->ed_double)[currentEdge] = double_value;
	  (currentEData->value_specified)[currentEdge] = true;
	}
      }
      break;
    case GraphML::string_data:
      string_value = xmlch2string(chars);
      if(withinDefault){
	if(nData){
	  currentNData->string_default += string_value;
	}
	if(eData){
	  currentEData->string_default += string_value;
	}
      }
      if(withinData){
	if(nData){
	  (currentNData->nd_string)[currentNode] += string_value;
	  (currentNData->value_specified)[currentNode] = true;
	}
	if(eData){
	  (currentEData->ed_string)[currentEdge] += string_value;
	  (currentEData->value_specified)[currentEdge] = true;
	}
      }
      break;
    case GraphML::bool_data:
      boolean_value = xmlch2bool(chars);
      if(withinDefault){
	if(nData){
	  currentNData->bool_default = boolean_value;
	}
	if(eData){
	  currentEData->bool_default = boolean_value;
	}
      }
      if(withinData){
	if(nData){
	  (currentNData->nd_bool)[currentNode] = boolean_value;
	  (currentNData->value_specified)[currentNode] = true;
	}
	if(eData){
	  (currentEData->ed_bool)[currentEdge] = boolean_value;
	  (currentEData->value_specified)[currentEdge] = true;
	}
      }
      break;
    }
  }
  if(withinKey && withinDesc){
    string s = xmlch2string(chars);
    if(nData) {
      currentNData->desc += s;
    }
    if(eData){
      currentEData->desc += s;
    }
  }
}//end characters

void GraphML_handler::startPrefixMapping (const XMLCh *const prefix, const XMLCh *const uri){
  string str_uri = xmlch2string(uri);
  //we handle only the GraphML namespace
  if(gr_leda.ns_uri() == str_uri){
    string p = xmlch2string(prefix);
    //update the list of GraphML prefixes...
    prefixes.append(p);
    //... and the current GraphML prefix in the class graphml
    gr_leda.set_graphml_prefix(p);
  }
}


void GraphML_handler::endPrefixMapping (const XMLCh *const prefix){
  //search for 'prefix' in the list of GraphML prefixes
  if(!prefixes.empty()){
    string p = xmlch2string(prefix);
    if(prefixes.back() == p){
      //if it matches: remove it 
      prefixes.pop_back();
      //and update the current GraphML prefix in the class graphml
      if(!prefixes.empty()){
	gr_leda.set_graphml_prefix(prefixes.back());
      }
      else{
	gr_leda.set_graphml_prefix("");
      }
    }
  }
}


void GraphML_handler::startGraphMLElement(string q_name, const Attributes &attributes){
}

//counts graphs
void GraphML_handler::startGraphElement(const Attributes &attributes){
  ++graph_level;
  if(graph_level == 1){
    ++tlgraph_count; 
  }
  if(graph_level == 1 && tlgraph_count == 1){
    if(attributeValue(attributes, gr_leda.graph_edgedefault()) == string("undirected"))
      undirected = true;
    else
      undirected = false;
  }
}

void GraphML_handler::startKeyElement(const Attributes &attributes){
  withinKey = true;
  string d("");//serves as default description
  string id = attributeValue(attributes, gr_leda.key_id());
  string for_attr = attributeValue(attributes, gr_leda.key_for());
  string name = attributeValue(attributes, gr_leda.key_name());
  string type = attributeValue(attributes, gr_leda.key_type());
  if(for_attr == gr_leda.node_ln()){
    //generate a new NodeData
    nData = true;
    if(type == gr_leda.key_type_int()){
      node_map<int> nMap(g);
      nd4p *nd = new nd4p(0, name, GraphML_graph::int_data, nMap, 0, d);
      currentNData = nd;
      nDataById.insert(id, nd);
    }
    if(type == gr_leda.key_type_long()){
      node_map<long> nMap(g);
      nd4p *nd = new nd4p(0, name, GraphML_graph::long_data, nMap, 0, d);
      currentNData = nd;
      nDataById.insert(id, nd);
    }
    if(type == gr_leda.key_type_float()){
      node_map<float> nMap(g);
      nd4p *nd = new nd4p(0, name, GraphML_graph::float_data, nMap, 0, d);
      currentNData = nd;
      nDataById.insert(id, nd);
    }
    if(type == gr_leda.key_type_double()){
      node_map<double> nMap(g);
      nd4p *nd = new nd4p(0, name, GraphML_graph::double_data, nMap, 0, d);
      currentNData = nd;
      nDataById.insert(id, nd);
    }
    if(type == gr_leda.key_type_string()){
      node_map<string> nMap(g);
      nd4p *nd = new nd4p(0, name, GraphML_graph::string_data, nMap, d, d);
      currentNData = nd;
      nDataById.insert(id, nd);
    }
    if(type == gr_leda.key_type_boolean()){
      node_map<bool> nMap(g);
      nd4p *nd = new nd4p(0, name, GraphML_graph::bool_data, nMap, false, d);
      currentNData = nd;
      nDataById.insert(id, nd);
    }
  }//end for = node
  if(for_attr == gr_leda.edge_ln()){
    //generate a new EdgeData
    eData = true;
    if(type == gr_leda.key_type_int()){
      edge_map<int> eMap(g);
      ed4p *ed = new ed4p(0, name, GraphML_graph::int_data, eMap, 0, d);
      currentEData = ed;
      eDataById.insert(id, ed);
    }
    if(type == gr_leda.key_type_long()){
      edge_map<long> eMap(g);
      ed4p *ed = new ed4p(0, name, GraphML_graph::long_data, eMap, 0, d);
      currentEData = ed;
      eDataById.insert(id, ed);
    }
    if(type == gr_leda.key_type_float()){
      edge_map<float> eMap(g);
      ed4p *ed = new ed4p(0, name, GraphML_graph::float_data, eMap, 0, d);
      currentEData = ed;
      eDataById.insert(id, ed);
    }
    if(type == gr_leda.key_type_double()){
      edge_map<double> eMap(g);
      ed4p *ed = new ed4p(0, name, GraphML_graph::double_data, eMap, 0, d);
      currentEData = ed;
      eDataById.insert(id, ed);
    }
    if(type == gr_leda.key_type_string()){
      edge_map<string> eMap(g);
      ed4p *ed = new ed4p(0, name, GraphML_graph::string_data, eMap, d, d);
      currentEData = ed;
      eDataById.insert(id, ed);
    }
    if(type == gr_leda.key_type_boolean()){
      edge_map<bool> eMap(g);
      ed4p *ed = new ed4p(0, name, GraphML_graph::bool_data, eMap, false, d);
      currentEData = ed;
      eDataById.insert(id, ed);
    }
  }//end for = edge
}

void GraphML_handler::startDefaultElement(const Attributes &attributes){
  withinDefault = true;
}

void GraphML_handler::startDescElement(){
  withinDesc = true;
}

void GraphML_handler::startDataElement(const Attributes &attributes){
  if(!ignore()){
    withinData = true;
    //look up the corresponding [Node|Edge]Data
    string key = attributeValue(attributes, gr_leda.data_key());
    if(nData){
      dic_item di = nDataById.lookup(key);
      if(di != nil){
	currentNData = nDataById.inf(di);
	if(currentNData->type == GraphML_graph::string_data){
	  currentNData->nd_string[currentNode] = string("");
	}
      }
      //if di == nil then the key attribute points to a 
      //key which is not for node 
      else{
	//cout << "key attribute: key=\"" << key << "\" points to wrong key" << endl; 
	withinData = false;
      }
    }
    if(eData){
      dic_item di = eDataById.lookup(key);
      if(di != nil){
	currentEData = eDataById.inf(di);
	if(currentEData->type == GraphML_graph::string_data){
	  currentEData->ed_string[currentEdge] = string("");
	}
      }
      //if di == nil then the key attribute points to a 
      //key which is not for edge 
      else{
	// cout << "key attribute: key=\"" << key << "\" points to wrong key" << endl; 
	withinData = false;
      }
    }
  }
}

void GraphML_handler::startNodeElement(const Attributes &attributes){
  if(!ignore()){
    nData = true;
    string id = attributeValue(attributes, gr_leda.node_id());
    //generate a new node
    //(if it hasn't been generated yet)
    dic_item it = nodeById.lookup(id);
    if(it == nil){
      node v = g.new_node();
      nodeById.insert(id,v);
    }
    //update the current node
    currentNode = nodeById.inf(nodeById.lookup(id));
  }
}

void GraphML_handler::startEdgeElement(const Attributes &attributes){
  if(!ignore()){
    eData = true;
    //generate a new edge
    string id = attributeValue(attributes, gr_leda.edge_source());
    //make sure that the source node has been generated
    dic_item it = nodeById.lookup(id);
    node source_node;
    if(it != nil){
      source_node = nodeById[it];
    }
    else{
      source_node = g.new_node();
      nodeById.insert(id, source_node);
    }

    id = attributeValue(attributes, gr_leda.edge_target());
    //make sure that the target node has been generated
    it = nodeById.lookup(id);
    node target_node;
    if(it != nil){
      target_node = nodeById[it];
    }
    else{
      target_node = g.new_node();
      nodeById.insert(id, target_node);
    }
    edge e = g.new_edge(source_node, target_node);
    //update the current edge
    currentEdge = e;
  }
}

void GraphML_handler::endGraphElement(){
  if(graph_level == 1 && tlgraph_count == 1){
    if(undirected)
      g.make_undirected();
    //add the node and edge-data to the graphml class
    dic_item it;
    forall_items(it,nDataById){
      nd4p nd = *(nDataById.inf(it));
      node v;
      switch(nd.type){
      case GraphML_graph::int_data:
	forall_nodes(v, g){
	  if(!nd.value_specified[v]) 
	    nd.nd_int[v] = nd.int_default;
	}				       
	gr_leda.new_data(nd.name, nd.type, nd.nd_int, nd.int_default, nd.desc);
	break;
      case GraphML_graph::long_data:
	forall_nodes(v, g){
	  if(!nd.value_specified[v]) 
	    nd.nd_long[v] = nd.long_default;
	}				       
	gr_leda.new_data(nd.name, nd.type, nd.nd_long, nd.long_default, nd.desc);
	break;
      case GraphML_graph::float_data:
	forall_nodes(v, g){
	  if(!nd.value_specified[v]) 
	    nd.nd_float[v] = nd.float_default;
	}				       
	gr_leda.new_data(nd.name, nd.type, nd.nd_float, nd.float_default, nd.desc);
	break;
      case GraphML_graph::double_data:
	forall_nodes(v, g){
	  if(!nd.value_specified[v]) 
	    nd.nd_double[v] = nd.double_default;
	}				       
	gr_leda.new_data(nd.name, nd.type, nd.nd_double, nd.double_default, nd.desc);
	break;
      case GraphML_graph::string_data:
	forall_nodes(v, g){
	  if(!nd.value_specified[v]) 
	    nd.nd_string[v] = nd.string_default;
	}				       
	gr_leda.new_data(nd.name, nd.type, nd.nd_string, nd.string_default, nd.desc);
	break;
      case GraphML_graph::bool_data:
	forall_nodes(v, g){
	  if(!nd.value_specified[v]) 
	    nd.nd_bool[v] = nd.bool_default;
	}				       
	gr_leda.new_data(nd.name, nd.type, nd.nd_bool, nd.bool_default, nd.desc);
	break;
      }
      delete nDataById.inf(it);
    }
    forall_items(it,eDataById){
      ed4p ed = *(eDataById.inf(it));
      edge e;
      switch(ed.type){
      case GraphML_graph::int_data:
	forall_edges(e, g){
	  if(!ed.value_specified[e]) 
	    ed.ed_int[e] = ed.int_default;
	}				       
	gr_leda.new_data(ed.name, ed.type, ed.ed_int, ed.int_default, ed.desc);
	break;
      case GraphML_graph::long_data:
	forall_edges(e, g){
	  if(!ed.value_specified[e]) 
	    ed.ed_long[e] = ed.long_default;
	}				       
	gr_leda.new_data(ed.name, ed.type, ed.ed_long, ed.long_default, ed.desc);
	break;
      case GraphML_graph::float_data:
	forall_edges(e, g){
	  if(!ed.value_specified[e]) 
	    ed.ed_float[e] = ed.float_default;
	}				       
	gr_leda.new_data(ed.name, ed.type, ed.ed_float, ed.float_default, ed.desc);
	break;
      case GraphML_graph::double_data:
	forall_edges(e, g){
	  if(!ed.value_specified[e]) 
	    ed.ed_double[e] = ed.double_default;
	}				       
	gr_leda.new_data(ed.name, ed.type, ed.ed_double, ed.double_default, ed.desc);
	break;
      case GraphML_graph::string_data:
	forall_edges(e, g){
	  if(!ed.value_specified[e]) 
	    ed.ed_string[e] = ed.string_default;
	}				       
	gr_leda.new_data(ed.name, ed.type, ed.ed_string, ed.string_default, ed.desc);
	break;
      case GraphML_graph::bool_data:
	forall_edges(e, g){
	  if(!ed.value_specified[e]) 
	    ed.ed_bool[e] = ed.bool_default;
	}				       
	gr_leda.new_data(ed.name, ed.type, ed.ed_bool, ed.bool_default, ed.desc);
	break;
      }
      delete eDataById.inf(it);
    }
  }
  nDataById.clear();
  eDataById.clear();
  --graph_level;
}


void GraphML_handler::endKeyElement(){
  nData = false;
  eData = false;
  withinKey = false;
}

void GraphML_handler::endDefaultElement(){
  withinDefault = false;
}

void GraphML_handler::endDescElement(){
  withinDesc = false;
}

void GraphML_handler::endDataElement(){
  withinData = false;
}

void GraphML_handler::endNodeElement(){
  nData = false;
}

void GraphML_handler::endEdgeElement(){
  eData = false;
}

bool GraphML_handler::ignore(){
  //we process only the first top level graph
  bool retVal = (graph_level == 1) && (tlgraph_count == 1);
  return !retVal;
}


//===============================================
//NodeData
//===============================================
nd4p::nd4p(){}

nd4p::nd4p(int i, string n, GraphML_graph::gm_data_type t, node_map<int> &d, int def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  nd_int(d),
  int_default(def),
  desc(des){}

nd4p::nd4p(int i, string n, GraphML_graph::gm_data_type t, node_map<long> &d, long def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  nd_long(d),
  long_default(def),
  desc(des){}

nd4p::nd4p(int i, string n, GraphML_graph::gm_data_type t, node_map<float> &d, float def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  nd_float(d),
  float_default(def),
  desc(des){}

nd4p::nd4p(int i, string n, GraphML_graph::gm_data_type t, node_map<double> &d, double def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  nd_double(d),
  double_default(def),
  desc(des){}

nd4p::nd4p(int i, string n, GraphML_graph::gm_data_type t, node_map<string> &d, string def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  nd_string(d),
  string_default(def),
  desc(des){}

nd4p::nd4p(int i, string n, GraphML_graph::gm_data_type t, node_map<bool> &d, bool def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  nd_bool(d),
  bool_default(def),
  desc(des){}

bool nd4p::hasDefaultData(node v){
  switch(type){
  case GraphML_graph::int_data:
    return nd_int[v] == int_default;
    break;
  case GraphML_graph::long_data:
    return nd_long[v] == long_default;
    break;
  case GraphML_graph::float_data:
    return nd_float[v] == float_default;
    break;
  case GraphML_graph::double_data:
    return nd_double[v] == double_default;
    break;
  case GraphML_graph::string_data:
    return nd_string[v] == string_default;
    break;
  case GraphML_graph::bool_data:
    return nd_bool[v] == bool_default;
    break;
  }
  return false;
}

//================================================
//EdgeData
//================================================
ed4p::ed4p(){}

ed4p::ed4p(int i, string n, GraphML_graph::gm_data_type t, edge_map<int> &d, int def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  ed_int(d),
  int_default(def),
  desc(des){}

ed4p::ed4p(int i, string n, GraphML_graph::gm_data_type t, edge_map<long> &d, long def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  ed_long(d),
  long_default(def),
  desc(des){}

ed4p::ed4p(int i, string n, GraphML_graph::gm_data_type t, edge_map<float> &d, float def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  ed_float(d),
  float_default(def),
  desc(des){}

ed4p::ed4p(int i, string n, GraphML_graph::gm_data_type t, edge_map<double> &d, double def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  ed_double(d),
  double_default(def),
  desc(des){}

ed4p::ed4p(int i, string n, GraphML_graph::gm_data_type t, edge_map<string> &d, string def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  ed_string(d),
  string_default(def),
  desc(des){}

ed4p::ed4p(int i, string n, GraphML_graph::gm_data_type t, edge_map<bool> &d, bool def, string des):
  id(i),
  name(n),
  type(t),
  value_specified(d.get_graph(), false),
  ed_bool(d),
  bool_default(def),
  desc(des){
}

bool ed4p::hasDefaultData(edge e){
  switch(type){
  case GraphML_graph::int_data:
    return ed_int[e] == int_default;
    break;
  case GraphML_graph::long_data:
    return ed_long[e] == long_default;
    break;
  case GraphML_graph::float_data:
    return ed_float[e] == float_default;
    break;
  case GraphML_graph::double_data:
    return ed_double[e] == double_default;
    break;
  case GraphML_graph::string_data:
    return ed_string[e] == string_default;
    break;
  case GraphML_graph::bool_data:
    return ed_bool[e] == bool_default;
    break;
  }
  return false;
}
#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE
