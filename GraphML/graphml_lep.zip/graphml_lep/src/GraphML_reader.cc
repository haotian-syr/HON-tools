#include "GraphML_handler.h"
#include "GraphML_reader.h"

#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/framework/StdInInputSource.hpp>

#if defined(LEDA_STD_IO_HEADERS)
using std::cout;
using std::endl;
using std::ends;
#endif

#include <LEDA/stream.h> 

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

//=======================================================
//methods for reading a GraphML file
//=======================================================
//======================================================
//helper method
//=====================================================
char* leda_string2char(string s){
  int len = s.length();
  char *ret_val = new char[len+1];
  for(int i = 0; i < len; ++i){
    ret_val[i] = s[i];
  }
  ret_val[len] = *"\0";
  return ret_val;
}

string xmlch2str(const XMLCh *xmlch){
  char* s = XMLString::transcode(xmlch);
  string retVal = string(s);
  delete[] s;
  return retVal;
} 
//=======================================================

GraphML_reader::GraphML_reader(graph &g):
  GraphML_graph(g)
{}

GraphML_reader::~GraphML_reader()
{}


bool GraphML_reader::read(string filename){
  nodeDataDict.clear();
  edgeDataDict.clear();
  G.clear();
  try{
    XMLPlatformUtils::Initialize();
  }

  catch (const XMLException& e){
    //    cout << "Initialization of XMLPlatformUtils failed" << endl;
    //    cout << xmlch2str(e.getMessage()) << endl;
    //    cout << "abort reading file: " << filename << endl;
    return false;
  }
  //create a parser
  SAX2XMLReader *parser = XMLReaderFactory::createXMLReader();

  //==========set options============================

  //don't validate
  parser->setFeature(XMLString::transcode("http://xml.org/sax/features/validation"), false);

  int error_count = 0;

  try{
    GraphML_handler handler(G, *this);
    parser->setContentHandler(&handler);
    parser->setErrorHandler(&handler);
    //start parsing
    if(!(filename == string("-"))){
      char * f_name = leda_string2char(filename);
      parser->parse(f_name);
    }
    else{
      parser->parse(StdInInputSource());
    }
    error_count = parser->getErrorCount();
    //    cout << "error count = " << error_count << endl;
  }

  catch (const XMLException& e){
    cout << "XMLException while parsing file " << filename << endl;
    cout << xmlch2str(e.getMessage()) << endl;
    return false;
  }

  catch (const SAXParseException& e){
    cout << "SAXParseException while parsing file " << filename << endl;
    cout << xmlch2str(e.getMessage()) << endl;
    cout << "line: " << e.getLineNumber() << endl;
    cout << "column: " << e.getColumnNumber() << endl;
    return false;
  }

  catch (const SAXException& e){
    cout << "SAXException while parsing file " << filename << endl;
    cout << xmlch2str(e.getMessage()) << endl;
    return false;
  }

  delete parser;


  XMLPlatformUtils::Terminate();
  return true;
}

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE
