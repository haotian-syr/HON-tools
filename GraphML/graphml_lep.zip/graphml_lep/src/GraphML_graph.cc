#include "GraphML_graph.h"

#include <LEDA/error.h>

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE


GraphML_graph::GraphML_graph(graph &gr):
  data_handle(0),
  G(gr)
{}

GraphML_graph::~GraphML_graph(){

}


bool GraphML_graph::del_data(gm_handle_type handle){
  bool found = false;
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil){
    nodeDataDict.del_item(it);
    found = true;
  }
  if(!found){
    it = edgeDataDict.lookup(handle);
    if(it != nil){
      edgeDataDict.del_item(it);
      found = true;
    }
  }
  return found;
}

//======================================
//methods for data-getting
//========================================

//node data


list<GraphML_graph::gm_handle_type> GraphML_graph::node_data_handles(){
  dic_item it;
  list<gm_handle_type> retVal;
  forall_items(it, nodeDataDict){
    retVal.append(nodeDataDict.key(it));
  }
  return retVal;
}

list<GraphML_graph::gm_handle_type> GraphML_graph::edge_data_handles(){
  dic_item it;
  list<gm_handle_type> retVal;
  forall_items(it, edgeDataDict){
    retVal.append(edgeDataDict.key(it));
  }
  return retVal;
}

GraphML_graph::gm_data_type GraphML_graph::data_type(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].type;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].type;

#ifndef LEDA_CHECKING_OFF
  error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_type(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].type;
}

string GraphML_graph::data_name(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].name;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].name;

#ifndef LEDA_CHECKING_OFF
  error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_name(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].name;
}

string GraphML_graph::data_desc(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].desc;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].desc;

#ifndef LEDA_CHECKING_OFF
  error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_desc(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].desc;
}

template<>
node_array<int>& GraphML_graph::node_data<int>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::node_data<int>(gm_handle_type handle)"); 
  }
#endif
  return nodeDataDict[it].nd_int;
}

template<>
node_array<long>& GraphML_graph::node_data<long>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::node_data<long>(gm_handle_type handle)"); 
  }
#endif
  return nodeDataDict[it].nd_long;
}

template<>
node_array<float>& GraphML_graph::node_data<float>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::node_data<float>(gm_handle_type handle)"); 
  }
#endif
  return nodeDataDict[it].nd_float;
}

template<>
node_array<double>& GraphML_graph::node_data<double>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::node_data<double>(gm_handle_type handle)"); 
  }
#endif
  return nodeDataDict[it].nd_double;
}

template<>
node_array<string>& GraphML_graph::node_data<string>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::node_data<string>(gm_handle_type handle)"); 
  }
#endif
  return nodeDataDict[it].nd_string;
}

template<>
node_array<bool>& GraphML_graph::node_data<bool>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::node_data<bool>(gm_handle_type handle)"); 
  }
#endif
  return nodeDataDict[it].nd_bool;
}

template<>
int& GraphML_graph::data_default<int>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].int_default;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].int_default;

#ifndef LEDA_CHECKING_OFF
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_default<int>(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].int_default;
}

template<>
long& GraphML_graph::data_default<long>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].long_default;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].long_default;

#ifndef LEDA_CHECKING_OFF
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_default<long>(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].long_default;
}

template<>
float& GraphML_graph::data_default<float>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].float_default;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].float_default;

#ifndef LEDA_CHECKING_OFF
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_default<float>(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].float_default;
}

template<>
double& GraphML_graph::data_default<double>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].double_default;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].double_default;

#ifndef LEDA_CHECKING_OFF
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_default<double>(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].double_default;
}

template<>
string& GraphML_graph::data_default<string>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].string_default;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].string_default;

#ifndef LEDA_CHECKING_OFF
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_default<string>(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].string_default;
}

template<>
bool& GraphML_graph::data_default<bool>(gm_handle_type handle){
  dic_item it;
  it = nodeDataDict.lookup(handle);
  if(it != nil) return nodeDataDict[it].bool_default;

  it = edgeDataDict.lookup(handle);
  if(it != nil) return edgeDataDict[it].bool_default;

#ifndef LEDA_CHECKING_OFF
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::data_default<bool>(gm_handle_type handle)"); 
#endif
  return nodeDataDict[it].bool_default;
}


template<>
edge_array<int>& GraphML_graph::edge_data<int>(gm_handle_type handle){
  dic_item it;
  it = edgeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::edge_data<int>(int handle)"); 
  }
#endif
  return edgeDataDict[it].ed_int;
}

template<>
edge_array<long>& GraphML_graph::edge_data<long>(gm_handle_type handle){
  dic_item it;
  it = edgeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::edge_data<long>(int handle)"); 
  }
#endif
  return edgeDataDict[it].ed_long;
}

template<>
edge_array<float>& GraphML_graph::edge_data<float>(gm_handle_type handle){
  dic_item it;
  it = edgeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::edge_data_float(int handle)"); 
  }
#endif
  return edgeDataDict[it].ed_float;
}

template<>
edge_array<double>& GraphML_graph::edge_data<double>(gm_handle_type handle){
  dic_item it;
  it = edgeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::edge_data<double>(int handle)"); 
  }
#endif
  return edgeDataDict[it].ed_double;
}

template<>
edge_array<string>& GraphML_graph::edge_data<string>(gm_handle_type handle){
  dic_item it;
  it = edgeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::edge_data<string>(int handle)"); 
  }
#endif
  return edgeDataDict[it].ed_string;
}

template<>
edge_array<bool>& GraphML_graph::edge_data<bool>(gm_handle_type handle){
  dic_item it;
  it = edgeDataDict.lookup(handle);
#ifndef LEDA_CHECKING_OFF
  if(it == nil){
    error_handler(1, "GraphML ERROR: invalid handle \n in method: GraphML_graph::edge_data<bool>(int handle)"); 
  }
#endif
  return edgeDataDict[it].ed_bool;
}



//===============================================
//NodeData
//===============================================
NodeData::NodeData(){}

NodeData::NodeData(int i, string n, GraphML_graph::gm_data_type t, node_array<int> &d, int def, string des):
  id(i),
  name(n),
  type(t),
  nd_int(d),
  int_default(def),
  desc(des){}

NodeData::NodeData(int i, string n, GraphML_graph::gm_data_type t, node_array<long> &d, long def, string des):
  id(i),
  name(n),
  type(t),
  nd_long(d),
  long_default(def),
  desc(des){}

NodeData::NodeData(int i, string n, GraphML_graph::gm_data_type t, node_array<float> &d, float def, string des):
  id(i),
  name(n),
  type(t),
  nd_float(d),
  float_default(def),
  desc(des){}

NodeData::NodeData(int i, string n, GraphML_graph::gm_data_type t, node_array<double> &d, double def, string des):
  id(i),
  name(n),
  type(t),
  nd_double(d),
  double_default(def),
  desc(des){}

NodeData::NodeData(int i, string n, GraphML_graph::gm_data_type t, node_array<string> &d, string def, string des):
  id(i),
  name(n),
  type(t),
  nd_string(d),
  string_default(def),
  desc(des){}

NodeData::NodeData(int i, string n, GraphML_graph::gm_data_type t, node_array<bool> &d, bool def, string des):
  id(i),
  name(n),
  type(t),
  nd_bool(d),
  bool_default(def),
  desc(des){}

bool NodeData::hasDefaultData(node v){
  switch(type){
  case GraphML_graph::int_data:
    return nd_int[v] == int_default;
    break;
  case GraphML_graph::long_data:
    return nd_long[v] == long_default;
    break;
  case GraphML_graph::float_data:
    return nd_float[v] == float_default;
    break;
  case GraphML_graph::double_data:
    return nd_double[v] == double_default;
    break;
  case GraphML_graph::string_data:
    return nd_string[v] == string_default;
    break;
  case GraphML_graph::bool_data:
    return nd_bool[v] == bool_default;
    break;
  }
  return false;
}

//================================================
//EdgeData
//================================================
EdgeData::EdgeData(){}

EdgeData::EdgeData(int i, string n, GraphML_graph::gm_data_type t, edge_array<int> &d, int def, string des):
  id(i),
  name(n),
  type(t),
  ed_int(d),
  int_default(def),
  desc(des){}

EdgeData::EdgeData(int i, string n, GraphML_graph::gm_data_type t, edge_array<long> &d, long def, string des):
  id(i),
  name(n),
  type(t),
  ed_long(d),
  long_default(def),
  desc(des){}

EdgeData::EdgeData(int i, string n, GraphML_graph::gm_data_type t, edge_array<float> &d, float def, string des):
  id(i),
  name(n),
  type(t),
  ed_float(d),
  float_default(def),
  desc(des){}

EdgeData::EdgeData(int i, string n, GraphML_graph::gm_data_type t, edge_array<double> &d, double def, string des):
  id(i),
  name(n),
  type(t),
  ed_double(d),
  double_default(def),
  desc(des){}

EdgeData::EdgeData(int i, string n, GraphML_graph::gm_data_type t, edge_array<string> &d, string def, string des):
  id(i),
  name(n),
  type(t),
  ed_string(d),
  string_default(def),
  desc(des){}

EdgeData::EdgeData(int i, string n, GraphML_graph::gm_data_type t, edge_array<bool> &d, bool def, string des):
  id(i),
  name(n),
  type(t),
  ed_bool(d),
  bool_default(def),
  desc(des){
}

bool EdgeData::hasDefaultData(edge e){
  switch(type){
  case GraphML_graph::int_data:
    return ed_int[e] == int_default;
    break;
  case GraphML_graph::long_data:
    return ed_long[e] == long_default;
    break;
  case GraphML_graph::float_data:
    return ed_float[e] == float_default;
    break;
  case GraphML_graph::double_data:
    return ed_double[e] == double_default;
    break;
  case GraphML_graph::string_data:
    return ed_string[e] == string_default;
    break;
  case GraphML_graph::bool_data:
    return ed_bool[e] == bool_default;
    break;
  }
  return false;
}
#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE
