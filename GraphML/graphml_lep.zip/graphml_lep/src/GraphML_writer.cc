#include "GraphML_writer.h"

#include <LEDA/error.h>

#include <LEDA/stream.h> 

#if defined(LEDA_STD_IO_HEADERS)
using std::ostream;
using std::ofstream;
using std::endl;
using std::ends;
#endif

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

//===================================================
//helper method
//===================================================


string GraphML_writer::bool2string(bool b){
  if(b) return string("true");
  else return string("false");
}
//substitutes the 'forbidden' chars 
// & < > ' "
//by their character entities
string GraphML_writer::escape_chars(const string &str){
  string retVal = str.replace_all("&", "&amp;");
  retVal = retVal.replace_all("<", "&lt;");
  retVal = retVal.replace_all(">", "&gt;");
  retVal = retVal.replace_all("'", "&apos;");
  retVal = retVal.replace_all("\"", "&quot;");
  return retVal;
}

GraphML_writer::GraphML_writer(graph &gr):
  GraphML_graph(gr)
{}

GraphML_writer::~GraphML_writer(){

}




//======================================
//Methods for writing
//======================================

bool GraphML_writer::write(string filename, gm_specification_type spec, bool p_info){
  file_ostream out(filename);
  if(out.fail()){
    //cout << "couldn't open file: " << filename << endl;
    return false;
  }
  write(out, spec, p_info);
  return true;
}


void GraphML_writer::write(ostream &out, gm_specification_type spec, bool p_info){

  out << XML_DECL << endl;

  out << endl;

  if(spec == dtd_spec){
    out << DOCTYPE_DECL << endl;
  }

  out << beginStartTag(graphml_qn());
  out << endl;

  out << "xmlns";
  if(is_prefixed()){
    out << COLON << get_graphml_prefix();
  }
  out << "=\"" << ns_uri() << "\"" << endl;

  if(spec == schema_spec){
    writeSchemaLocation(out, p_info);
  }

  out << closeTag() << endl;

  writeKeys(out);

  writeGraph(out, p_info);

  out << endTag(graphml_qn()) << endl;


}//end of write


void GraphML_writer::writeSchemaLocation(ostream &out, bool p_info){
  out << "xmlns" << COLON << XSI_PREFIX 
      << "=\"http://www.w3.org/2001/XMLSchema-instance\"" << endl;
  out << XSI_PREFIX << COLON << "schemaLocation=\"" 
      << SCHEMA_LOCATION; 
  if(p_info){
    out << "\n\n        	    " << ns_uri() << "\n"
        << "        	    graphml-parseinfo-1.0rc.xsd";
  }
  out  << "\"" << endl;
}

void GraphML_writer::writeKeys(ostream &out){
  if(!nodeDataDict.empty()){
    dic_item it;
    forall_items(it,nodeDataDict){
      NodeData &nd = nodeDataDict[it];
      writeKey(out,nd);
    }
  }
  if(!edgeDataDict.empty()){
    dic_item it;
    forall_items(it,edgeDataDict){
      EdgeData &ed = edgeDataDict[it];
      writeKey(out, ed);
    }
  }
}

void GraphML_writer::writeKey(ostream &out, NodeData &nd){
  writeIndent(out, 1);
  out << beginStartTag(key_qn()) << key_id() << "=\"k" << nd.id << "\" ";
  out << key_for() << "=\"" << node_ln() << "\" ";
  out << key_name() << "=\"" << nd.name << "\" ";

  out << key_type() << "=\"";
  switch(nd.type){
  case GraphML_writer::int_data:
    out << key_type_int() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, nd);
    writeDefault(out, num2string(nd.int_default));
    break;
  case GraphML_writer::long_data:
    out << key_type_long() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, nd);
    writeDefault(out, num2string(nd.long_default));
    break;
  case GraphML_writer::float_data:
    out << key_type_float() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, nd);
    writeDefault(out, num2string(nd.float_default));
    break;
  case GraphML_writer::double_data:
    out << key_type_double() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, nd);
    writeDefault(out, num2string(nd.double_default));
    break;
  case GraphML_writer::string_data:
    out << key_type_string() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, nd);
    writeDefault(out, escape_chars(nd.string_default));
    break;
  case GraphML_writer::bool_data:
    out << key_type_boolean() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, nd);
    writeDefault(out, bool2string(nd.bool_default));
    break;
  }
 
  writeIndent(out, 1);
  out << endTag(key_qn()) << "\n";
}

void GraphML_writer::writeDesc(ostream &out, NodeData &nd){
  if(nd.desc.length() > 0){
    writeIndent(out, 2);
    out << "<" << desc_qn() << closeTag() << escape_chars(nd.desc) << endTag(desc_qn()) << "\n";
  }
}

void GraphML_writer::writeKey(ostream &out, EdgeData &ed){
  writeIndent(out, 1);
  out << beginStartTag(key_qn()) << key_id() << "=\"k" << ed.id << "\" ";
  out << key_for() << "=\"" << edge_ln() << "\" ";
  out << key_name() << "=\"" << ed.name << "\" ";

  out << key_type() << "=\"";
  switch(ed.type){
  case GraphML_writer::int_data:
    out << key_type_int() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, ed);
    writeDefault(out, num2string(ed.int_default));
    break;
  case GraphML_writer::long_data:
    out << key_type_long() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, ed);
    writeDefault(out, num2string(ed.long_default));
    break;
  case GraphML_writer::float_data:
    out << key_type_float() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, ed);
    writeDefault(out, num2string(ed.float_default));
    break;
  case GraphML_writer::double_data:
    out << key_type_double() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, ed);
    writeDefault(out, num2string(ed.double_default));
    break;
  case GraphML_writer::string_data:
    out << key_type_string() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, ed);
    writeDefault(out, escape_chars(ed.string_default));
    break;
  case GraphML_writer::bool_data:
    out << key_type_boolean() << "\"";
    out << closeTag() << "\n";
    writeDesc(out, ed);
    writeDefault(out, bool2string(ed.bool_default));
    break;
  } 

  writeIndent(out, 1);
  out << endTag(key_qn()) << "\n";
}

void GraphML_writer::writeDesc(ostream &out, EdgeData &ed){
  if(ed.desc.length() > 0){
    writeIndent(out, 2);
    out << "<" << desc_qn() << closeTag() << escape_chars(ed.desc) << endTag(desc_qn()) << "\n";
  }
}

void GraphML_writer::writeDefault(ostream &out, string data){
  writeIndent(out, 2); 
  out << "<" << default_qn() << closeTag();
  out << data;
  out << endTag(default_qn()) << "\n";
}

void GraphML_writer::writeGraph(ostream &out, bool p_info){

  writeIndent(out, 1);
  out << beginStartTag(graph_qn());

  //graph attributes
  out << graph_edgedefault() << "=\"";
  if(G.is_directed()){
    out << "directed";
  }
  else{
    out << "undirected";
  }
  out << "\"";

  if(p_info){
    out << "\n         " 
        << graph_nodeids() << "=\"" << graph_nodeids_canonical() << "\" "
        << graph_edgeids() << "=\"" << graph_edgeids_canonical() << "\"";
    out << "\n         "
        << graph_order() << "=\"" << graph_order_nodesfirst() << "\"";
    out << "\n         "
        << graph_nodes() << "=\"" << G.number_of_nodes() << "\" "
        << graph_edges() << "=\"" << G.number_of_edges() << "\"";
    //calculate the maximal indegree and maximal outdegree
    int maxindeg = 0;
    int maxoutdeg = 0;
    node v;
    forall_nodes(v, G){
      if(G.indeg(v) > maxindeg)
	maxindeg = G.indeg(v);
      if(G.outdeg(v) > maxoutdeg)
	maxoutdeg = G.outdeg(v);
    }
    out << "\n         "
        << graph_maxindegree() << "=\"" << maxindeg << "\" "
        << graph_maxoutdegree() << "=\"" << maxoutdeg << "\"";
    out << "\n"; 
    writeIndent(out, 1);
  }//end of parse info

  out << closeTag() << "\n";

  //nodes

  //node array saving the number of each node
  node_array<int> n_num(G);

  node v;  
  unsigned int count = 0; 

  forall_nodes(v, G){
    n_num[v] = count;
    writeNode(out, count, v, p_info);
    ++count; 
  }

  //edges

  edge e;

  forall_edges(e, G){
    v = G.source(e);
    unsigned int source = n_num[v];

    v = G.target(e);
    unsigned int target = n_num[v];

    writeEdge(out, source, target, e);
  }
  

  writeIndent(out, 1);
  out << endTag(graph_qn()) << "\n";
}//end of writeGraph

void GraphML_writer::writeNode(ostream &out, unsigned int count, node v, bool p_info){

  writeIndent(out, 2);

  out << beginStartTag(node_qn());

  out << node_id() << "=\"n" << count << "\"";

  if(p_info){
    out << " " << node_indegree() << "=\"" << G.indeg(v) << "\" "
        << node_outdegree() << "=\"" << G.outdeg(v) << "\""; 
  }//end parse info

  out << closeTag() << "\n";

  //content of node
  writeNodeData(out, v);

  writeIndent(out, 2);

  out << endTag(node_qn()) << "\n";


}//end of writeNode

void GraphML_writer::writeNodeData(ostream &out, node v){
  dic_item it;
  forall_items(it, nodeDataDict){
    NodeData &nd = nodeDataDict[it];
    if(!nd.hasDefaultData(v)){
      writeIndent(out,3);
      out << beginStartTag(data_qn());
      out << data_key() << "=\"k" << nd.id << "\"" << closeTag();
      switch(nd.type){
      case GraphML_writer::int_data:
	out << nd.nd_int[v];
	break;
      case GraphML_writer::long_data:
	out << nd.nd_long[v];
	break;
      case GraphML_writer::float_data:
	out << nd.nd_float[v];
	break;
      case GraphML_writer::double_data:
	out << nd.nd_double[v];
	break;
      case GraphML_writer::string_data:
	out << escape_chars(nd.nd_string[v]);
	break;
      case GraphML_writer::bool_data:
	out << bool2string(nd.nd_bool[v]);
	break;
      }
      out << endTag(data_qn()) << "\n";
    }
  }
}

void GraphML_writer::writeEdge(ostream &out, unsigned int source, unsigned int target, edge e){

  writeIndent(out, 2);

  out << beginStartTag(edge_qn());

  out << edge_source() << "=\"n" << source << "\" ";

  out << edge_target() << "=\"n" << target << "\"";

  out << closeTag() << "\n";

  //content of edge
  writeEdgeData(out, e);

  writeIndent(out, 2);

  out << endTag(edge_qn()) << "\n";


}//end of writeEdge

void GraphML_writer::writeEdgeData(ostream &out, edge e){
  dic_item it;
  forall_items(it, edgeDataDict){
    EdgeData &ed = edgeDataDict[it];
    if(!ed.hasDefaultData(e)){
      writeIndent(out,3);
      out << beginStartTag(data_qn());
      out << data_key() << "=\"k" << ed.id << "\"" << closeTag();
      switch(ed.type){
      case GraphML_writer::int_data:
	out << ed.ed_int[e];
	break;
      case GraphML_writer::long_data:
	out << ed.ed_long[e];
	break;
      case GraphML_writer::float_data:
	out << ed.ed_float[e];
	break;
      case GraphML_writer::double_data:
	out << ed.ed_double[e];
	break;
      case GraphML_writer::string_data:
	out << escape_chars(ed.ed_string[e]);
	break;
      case GraphML_writer::bool_data:
	out << bool2string(ed.ed_bool[e]);
	break;
      }
      out << endTag(data_qn()) << "\n";
    }
  }
}

void GraphML_writer::writeIndent(ostream &out, unsigned int treedepth=1){
  for(unsigned int i=0; i<treedepth; ++i){
    out << "  ";
  }
}

const string GraphML_writer::beginStartTag(const string &elementName) {
  string retVal("<");
  retVal = retVal+elementName+" ";
  return retVal;
}

const string GraphML_writer::endTag(const string &elementName) {
  string retVal("</");
  retVal = retVal + elementName + ">";
  return retVal;
}

const string GraphML_writer::closeTag() {
  return string(">");
}

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE
