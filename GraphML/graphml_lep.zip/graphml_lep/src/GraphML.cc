#include "GraphML.h"

#ifndef LEDA_BEGIN_NAMESPACE
#define LEDA_BEGIN_NAMESPACE
#endif
LEDA_BEGIN_NAMESPACE

GraphML::GraphML(graph &gr):
  GraphML_graph(gr),
  GraphML_reader(gr),
  GraphML_writer(gr)
{}

GraphML::~GraphML(){

}

#ifndef LEDA_END_NAMESPACE
#define LEDA_END_NAMESPACE
#endif
LEDA_END_NAMESPACE
