BiocGenerics:::testPackage("hypergraph")
